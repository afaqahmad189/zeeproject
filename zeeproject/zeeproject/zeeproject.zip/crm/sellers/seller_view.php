<!DOCTYPE html>
<html>
<head>

<style>
	
	.table{

		background-color: white;
	}

	th{
		width: 150px;
	}


</style>


	<title>Seller Details</title>
</head>
<body>



<?php include '../../header.php';?>



<div class="rowmargin">
	


	<div class="row"> 

		<div style="padding: 10px; max-width: 30%" class="col card ">
			
			
			<center>

				<h1 style="margin-bottom: 20px">KarWish</h1>

			<img align="center" width="180px" src="https://cdn1.iconfinder.com/data/icons/avatar-97/32/avatar-02-512.png"><br></center><br>

			<table class="table text-center">

				<tr>

					<td>Ratings</td>
					<td>5 Stars</td>

				</tr>	
				
				

				<tr>

					<td>Seller Type</td>
					<td>Active Seller</td>

				</tr>	

			</table>
			<br>

			<table class="table text-center">
				
				

				<tr>

					<th>Product Name</th>
					<th>Price</th>
					<th>Date</th>

				</tr>

				<tr>	
					
					<td>
						
						Bulb
					
					</td>

					<td>
						
						500
					
					</td>

					<td>
						
						03/05/2020
					
					</td>

				</tr>

				<tr>	
					
					<td>
						
						Light
					
					</td>

					<td>
						
						980
					
					</td>

					<td>
						
						21/02/2020
					
					</td>

				</tr>

				<tr>	
					
					<td>
						
						Wire
					
					</td>

					<td>
						
						140
					
					</td>

					<td>
						
						18/10/2020
					
					</td>

				</tr>


				
	


			</table>

			<br>
			<button style="font-size: 24px; margin-bottom: 8px" class="btn btn-primary viewpagebtn">Edit</button>
			<button style="font-size: 24px" class="btn btn-warning viewpagebtn">Khata</button> <!--- Khata button only show if Seller Type = Active Seller --->

			

		</div>


		<div style="padding: 20px; margin-left: 15px" class="col card ">
			
			<table class="table text-center">
				

				<tr>
					<th>Dealer Name</th>
					<th>Phone</th>
					<th>Account Numbers</th>
				</tr>

				<tr>
					<td>Ali</th>
					<td>1234567</th>
					<td>97754324677</th>
				</tr>

				<tr>
					<td>Ali</th>
					<td>1234567</th>
					<td>97754324677</th>
				</tr>

				<tr>
					<td>Ali</th>
					<td>1234567</th>
					<td>97754324677</th>
				</tr>

				<tr>
					<td>Ali</th>
					<td>1234567</th>
					<td>97754324677</th>
				</tr>


			</table>

			<br>

			<table class="table text-center">
				
				<tr>
					
					<th>Shop Addresses</th>

				</tr>

				<tr>
					
					<td>Lahore</td>
					

				</tr>

				<tr>
					
					<td>Islamabad</td>

				</tr>

				<tr>
					
					<td>Karachi</td>

				</tr>


			</table>

<br>
			
			<table class="table text-center">
				
				

				


				<tr>

					<th>Description</td>
				</tr>
				
				<tr>		
					<td>
					
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum lorem odio, pulvinar eu consequat eu, sollicitudin eget nibh. Pellentesque consectetur arcu dolor, vitae blandit est blandit elementum. Fusce vehicula in libero in euismod. In </p>
						


					</td>

				</tr>	
	


			</table>

			<br>

			

			


		</div>








	</div><br><!--- row 1 ending --->



	

<!---
		<div style="padding: 10px" class="card ">

			<h5>Description</h5>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum lorem odio, pulvinar eu consequat eu, sollicitudin eget nibh. Pellentesque consectetur arcu dolor, vitae blandit est blandit elementum. Fusce vehicula in libero in euismod. In hac habitasse platea dictumst. Nullam feugiat convallis ex ac interdum. Cras ultricies consequat massa, vitae egestas eros commodo quis. Nullam at efficitur est, vel vulputate dui. Sed eleifend egestas tortor vitae laoreet. Curabitur ac ultricies leo. Suspendisse ut augue sit amet velit blandit hendrerit. Nullam a urna elit. Pellentesque tincidunt, ex sed egestas dapibus, purus mauris pharetra arcu, dictum suscipit mi odio at mi. Etiam tristique, augue sed pharetra feugiat, mauris ante tincidunt ex, dictum dapibus enim dolor id nisl. Praesent sit amet bibendum dolor. Ut a semper neque. Aenean vitae eros nisl.

					</p>


		</div>  --->












</div><!--- ending row margin --->








<?php include '../../footer.html';?>

</body>
</html>