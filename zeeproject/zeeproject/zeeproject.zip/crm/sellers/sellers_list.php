<!DOCTYPE html>
<html>
<head>
	<title>Seller Lists</title>
</head>


<style>
	
	th {
  height: 250px!important;
  
	}

.table{

		background-color: white!important;
		padding: 20px!important;
	}

	.table > tbody > tr > td {
     vertical-align: middle;
}

.table > tbody > tr > th {
     height: 50px!important;
}

.headrow{

	margin-bottom: 50px;
}


</style>






<body>

	<?php include '../../header.php';?>

<div style="padding: 15px">

	<div class="row">

	<div style="padding: 0" class="col align-middle">

	<button class="btn btn-primary">CSV</button>
	<button class="btn btn-primary">Excel</button>
	<button class="btn btn-primary">Print</button>


	</div>

	<div style="padding: 0" class="col align-middle float-right">
		

		<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Search Here By Name Or Product" aria-label="Recipient's username" aria-describedby="basic-addon2">
  <div class="input-group-append">
    <button class="btn btn-primary" type="button">Search</button>
  </div>
</div>


		<!---

		<input style="width: 100%; height: 50px; padding: 10px;" type="text" class="form-contol searchform" placeholder="Search Product" name="">


		--->

		


	</div>



	</div>



	

	<table style="padding: 50px; margin-top: 5px" class="table text-center">
		
		<tr class="headrow" style="margin-bottom: 5px">

			<th>ID</th>
			<th>Seller Type</th>
			<th>Seller Shop Name</th>
			<th>Category</th>
			<th>Khata</th>
			<th>Action</th>
			


		</tr>



		<tr>
			

			<td>1</td>
			<td>Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						
						
					

			</td>

			<td>
						
						<a href="/zeeproject/crm/sellers/seller_view.php?seller_id=1">
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<a href="/zeeproject/crm/sellers/edit_seller.php?seller_id=1"><button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button></a>
						

						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

			

		</tr>


		<tr>
			

			<td>2</td>
			<td>Active Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						<a href="/zeeproject/crm/sellers/insert_khata.php?seller_id=1"><button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i> View</button>

						
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>3</td>
			<td>Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>

		<tr>
			

			<td>4</td>
			<td>Active Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						<a href="/zeeproject/crm/sellers/insert_khata.php?seller_id=1"><button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i> View</button>
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>5</td>
			<td>Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>6</td>
			<td>Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>7</td>
			<td>Active Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						<a href="/zeeproject/crm/sellers/insert_khata.php?seller_id=1"><button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i> View</button>
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>

		<tr>
			

			<td>8</td>
			<td>Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						
						
					

			</td>


			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>9</td>
			<td>Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>10</td>
			<td>Active Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						<a href="/zeeproject/crm/sellers/insert_khata.php?seller_id=1"><button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i> View</button>
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>11</td>
			<td>Active Seller</td>
			<td>Shop name 1</td>
			<td>Electronics</td>

			<td>
						
						<a href="/zeeproject/crm/sellers/insert_khata.php?seller_id=1"><button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i> View</button>
						
					

			</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>









	</table>




</div>


	<?php include '../../footer.html';?>


</body>
</html>
