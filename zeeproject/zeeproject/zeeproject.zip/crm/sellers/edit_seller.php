<!DOCTYPE html>
<html>
<head>

	<style>
		
		


		.repeaterbtn{

	height: 40px;
    margin-top: 30px;
				
				}		

		
	</style>


	<title>Edit Seller</title>
</head>
<body>

	<?php include '../../header.php';?>


<div class="container">


		
		<h3 class="pageheading">Edit Seller </h3>
		<br>


		<form>
			
			<label for="sellertype">Select Seller Type</label>
			<select id="sellertype" class="form-control">
				
				<option>Choose One..</option>
				<option value="seller">Seller</option>
				<option value="activeseller">Active Seller</option>

			</select><br>

			<label for="sellercompanyname">Enter Company/Seller Name</label>
			<input value="Shop name 1" id="sellercompanyname" type="text" class="form-control" placeholder="Enter Seller/Company Name" name=""><br>


			<!--- dealer name n phone dynamic field --->


			<div style="margin-top: 15px" class="row" data-ac-repeater>

				<div class="col">

					<label for="dealers">Enter Dealer Name</label>
					<input value="dealer 1" id="dealers" type="text" placeholder="Enter Dealer Name" class="form-control" name="">

				</div>

				<div class="col">

					<label for="contactnum">Contact Number</label>
					<input value="1234567" id="contactnum" type="text" placeholder="Enter Contact Number" class="form-control" name="">

				</div>

				<div class="col">

					<label for="accnum">Account Number</label>
					<input value="253200045620" id="accnum" type="text" placeholder="Enter Account Number" class="form-control" name="">

				</div>

			</div><br>




			<!--- ending dealer name n phone dynamic field --->




			<!--- products dynamic fields --->


			<div style="margin-top: 15px" class="row" data-ac-repeater>

				<div class="col">

					<label for="pname">Enter Product</label>
					<input value="product 1" id="pname" type="text" placeholder="Enter Product Name" class="form-control" name="">

				</div>

				<div class="col">

					<label for="pprice">Price</label>
					<input value="560" id="pprice" type="text" placeholder="Enter Price" class="form-control" name="">

				</div>

				<div class="col">

					<label for="pdate">Enter Date</label>
					<input id="pdate" type="date" placeholder="Enter Date" class="form-control" name="">

				</div>

			</div><br><br>




			<!--- ending products dynamic --->



			<!--- location dynamic fields --->


			<div style="margin-top: 15px" class="row" data-ac-repeater>

				<div class="col">

					<label for="pname">Enter Location</label>
					<input value="Lahore" id="pname" type="text" placeholder="Enter Location Name" class="form-control" name="">

				</div>

				

			

			</div><br><br>




			<!--- ending products dynamic --->





		



			<div  class="row"><!--- row 3 --->
				
				
				

				<div style="padding: 0; padding-left: 10px" class="col">
					
					<label for="sellerdescription">Enter Description</label>
					<textarea id="sellerdescription" class="form-control" placeholder="Enter Description" rows="8">Descriptiont testing for demo sample using on UI interface made by bootstrap. Develop by Hassan</textarea><br>

					
					
					

				</div>


			</div><br><!--- row 3 ending --->

			<div class="row">


				<div style="padding: 0px" class="col">
					
					<label for="dealercat">Dealer Category</label>
					<input value="electronics" type="text" id="dealercat" class="form-control" name="" placeholder="Enter Dealer Category Name"><br>

					


				</div>
				
				<div style="padding: 0px; padding-left: 20px;" class="col">
					

					<!--- star ratings  --->

					<label style="margin-bottom: 20px">Rating</label><br>
					<label class="radio-inline">
      				<input type="radio" name="optradio" checked> Rate 1
    				</label>
    				<label class="radio-inline">
      				<input style="margin-left: 30px;" type="radio" name="optradio"> Rate 2
    				</label>
    				<label class="radio-inline">
      				<input  style="margin-left: 30px;"  type="radio" name="optradio"> Rate 3
    				</label>
    				<label class="radio-inline">
      				<input style="margin-left: 30px;" type="radio" name="optradio"> Rate 4
    				</label>
    				<label class="radio-inline">
      				<input style="margin-left: 30px;" type="radio" name="optradio"> Rate 5
    				</label>



                   <!--- star ratings ending --->     

				</div>





			</div><!--- row 4 ending  --->

			<br>

			<label for="dealerpics">Dealer Pictures</label>
					<input style="height: 45px" type="file" class="form-control" name="" id="dealerpics">




			<br><br>
			<center>


				<button type="submit" class="btn formbtn"> Update </button>

			</center>	






			





		</form>




</div>	



<script src="jquery.ac-form-field-repeater.js"></script>




<script>
	

	$(document).ready(function(){
    // Change text of input button
    $("#acAdder0").prop("value", "Input New Text");
    
    // Change text of button element
    $("#acAdder0").html("Add More");
});


$(document).ready(function(){
    // Change text of input button
   
    
    // Change text of button element
    $(".repeaterbtn").html("Add More");
});

</script>




	<?php include '../../footer.html';?>

</body>
</html>