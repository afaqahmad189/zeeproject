<!DOCTYPE html>
<html>
<head>




<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" integrity="sha256-KzZiKy0DWYsnwMF+X1DvQngQ2/FxF7MF3Ff72XcpuPs=" crossorigin="anonymous"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js"></script>


<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" integrity="sha256-h20CPZ0QyXlBuAw7A+KluUYx/3pK+c7lYEpqLTlxjYQ=" crossorigin="anonymous" />


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">





<link rel = "stylesheet" type="text/css" href = "/zeeproject/css/stylesheet.css"/>






<style>
	

.dropdown:hover .dropdown-content{
  display: block!important;
}

.navbar-dark .navbar-nav .nav-link {
    font-weight: 600;
    color: white;
    margin: 14px!important;
}

@media only screen and (max-width: 992px){
.navbar-toggler{

  float: right;
}

}




</style>




	<title></title>
</head>
<body>

<!--- HEADER START --->




<!--- topbar starting --->


<div  class="row topbar1">

  <div class="col-6 col-md-3 align-self-center topbarcol">
    <center>
   <h6 style="color: white"> 12: 26 AM / 12 Sept 2020 </h6>
    </center>
  </div>

  <div class="col-6 col-md-3 align-self-center topbarcol">
    
    <center>
    <img class="logo" width="60px" src="/zeeproject/media/images/logo.jpg" alt="BUZZTEK">
    </center>

  </div>

  <div class="col-6 col-md-3 align-self-center topbarcol">
    <center>
   <button class="topposbtn">POS</button>
 </center>

  </div>

  <div class="col-6 col-md-3 align-self-center topbarcol">
    
    <center>

    <h5 style="color: white"> ZeeShan Ali <i class="fa fa-arrow-down" aria-hidden="true"></i>
 </h5>

 </center>

  </div>


</div>  



<!--- topbar ending --->


    <div class="navbar navbar-expand-lg navbar-dark ">
        <div class="container"><span class="text-white d-md-none">POS</span><button class="btn btn-link navbar-toggler" data-toggle="collapse" data-target="#main-nav" type="button"><span class="navbar-toggler-icon"></span></button>
            <div id="main-nav" class="navbar-collapse collapse">
                <ul class="navbar-nav nav-fill w-100">
                    

                  <!---

                    <li class="nav-item"><a class="nav-link" href="/zeeproject/index.php"><i style="margin-right: 5px" class="fas fa-tachometer-alt"></i>  Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/zeeproject/inventory.php" ><i style="margin-right: 5px" class="fas fa-dolly-flatbed"></i> Inventory</a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i style="margin-right: 5px" class="far fa-file-alt"></i> Reports</a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i style="margin-right: 5px" class="fas fa-shopping-cart"></i> Sales</a></li>


                    <li class="nav-item"><a class="nav-link" href="#"><i style="margin-right: 5px" class="far fa-gem"></i> CRM</a></li>
              




                   


                    <li class="nav-item"><a class="nav-link" href="#"><i style="margin-right: 5px" class="fas fa-award"></i> HRM</a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i style="margin-right: 5px" class="fas fa-clipboard-list"></i> To do List</a></li>
                    <li class="nav-item"><a class="nav-link" href="#"><i style="margin-right: 5px" class="fas fa-truck-loading"></i> Pickup Orders</a></li>

  --->

                    <!--- nav 2 --->



                     <!--- dropdown 1 --->


                     <li>
                      
                    <div  class="dropdown1">
                      <a href="/zeeproject/index.php">
                      <button style="background-color: #ffffff00; color: white" class="btn  nav-link"  type="button">

                        <i style="margin-right: 5px" class="fas fa-tachometer-alt"></i> Dashboard </button></a></div> 


                    </li>

                    <li>


                    <div  class="dropdown"><button style="background-color: #ffffff00; color: white" class="btn dropdown-toggle  nav-link" data-toggle="dropdown" type="button"><i style="margin-right: 5px" class="fas fa-dolly-flatbed"></i> Inventory </button>
                      <div class="dropdown-menu">
                        <a class="dropdown-item" href="/zeeproject/inventory/inventory.php">Products List</a>
                        </div>

                    </div>
                    
                    </li>



                    <li>

                    <div  class="dropdown"><button style="background-color: #ffffff00; color: white" class="btn dropdown-toggle  nav-link" data-toggle="dropdown" type="button"><i style="margin-right: 5px" class="far fa-file-alt"></i> Reports </button>
                      <div class="dropdown-menu">

                        <a class="dropdown-item" href="/zeeproject/report/top.php">Top</a>

                        <a class="dropdown-item" href="/zeeproject/report">Overall</a>


                        <a class="dropdown-item" href="/zeeproject/report/products/products_reports.php">Products Report</a>
                        
                        <a class="dropdown-item" href="/zeeproject/report/customers/customers_report.php">Customers Report</a>
                        
                        <a class="dropdown-item" href="/zeeproject/report/sellers/sellers_report.php">Sellers Report</a></div>
                    
                    </div>

                    </li>


                    <li>

                    <div  class="dropdown">

                      <a href="#">
                      <button style="background-color: #ffffff00; color: white" class="btn  nav-link"  type="button"><i style="margin-right: 5px" class="fas fa-shopping-cart"></i> Sales </button> </a>


                    </div>
                    
                    </li>



                     <li>

                    <div  class="dropdown"><button style="background-color: #ffffff00; color: white" class="btn dropdown-toggle  nav-link" data-toggle="dropdown" type="button"><i style="margin-right: 5px" class="far fa-gem"></i> CRM </button>
                      <div class="dropdown-menu">
                        <a class="dropdown-item" href="/zeeproject/crm/sellers/sellers_list.php">Sellers</a>
                        <a class="dropdown-item" href="/zeeproject/crm/sellers/insert_seller.php">Insert New Seller</a>
                        <a class="dropdown-item" href="/zeeproject/crm/sellers/khata_list.php">Khata</a>
                        <a class="dropdown-item" href="/zeeproject/crm/sellers/insert_khata.php">Add New Khata</a></div>
                        
                    
                    </div>

                    </li>



                     <li>

                    <div  class="dropdown"><button style="background-color: #ffffff00; color: white" class="btn dropdown-toggle  nav-link" data-toggle="dropdown" type="button"><i style="margin-right: 5px" class="fas fa-award"></i> HRM </button>
                      <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">First Item</a>
                        <a class="dropdown-item" href="#">Second Item</a>
                        <a class="dropdown-item" href="#">Third Item</a></div>
                    
                    </div>

                    </li>



                     <li>

                    <div  class="dropdown"><button style="background-color: #ffffff00; color: white" class="btn  nav-link" data-toggle="dropdown" type="button"><i style="margin-right: 5px" class="fas fa-clipboard-list"></i> To Do List </button>
                      
                    </div>

                    </li>


                    <li>

                    <div  class="dropdown"><button style="background-color: #ffffff00; color: white" class="btn  nav-link" data-toggle="dropdown" type="button"><i style="margin-right: 5px" class="fas fa-truck-loading"></i> Pick Up Orders </button>
                      
                    </div>

                    </li>


                   

                    <!--- dropdown 1 ending --->



                    <!--- nav 2 ending --->



                </ul>
            </div>
        </div>
    </div>
    <br>




    <!--- second nav --->


   


    <!--- ending second nav --->




    <div class="spacerbyhasan"></div>

    
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="//code.jquery.com/jquery.min.js"></script>
</body>

</html>

<!--- HEADER END --->


<script src="js/jquery.min.js"></script>






</body>
</html>