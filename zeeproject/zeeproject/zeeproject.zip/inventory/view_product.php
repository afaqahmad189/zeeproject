<!DOCTYPE html>
<html>
<head>

<style>
	
	.table{

		background-color: white;
	}

	th{
		width: 150px;
	}


</style>


	<title>Seller Details</title>
</head>
<body>



<?php include '../header.php';?>



<div class="rowmargin">
	


	<div class="row">

		<div class="col-md-4 col-sm-12">

		<div style="padding: 10px;   height: 800px; " class="card fixedcard">
			
			
			<center>

				<h1 style="margin-bottom: 20px">Rocks Wires</h1>

			<img align="center" width="180px" src="https://5.imimg.com/data5/KV/GN/MY-14323962/flexible-wire-500x500.jpg"><br></center><br>

			


			<table class="table text-center">
				
				

				<tr>

					<th>Quantity</th>
					<th>Remaining Quantity</th>
					

				</tr>

				<tr>	
					
					<td>
						
						90
					
					</td>

					<td>
						
						60
					
					</td>

					

				</tr>


			</table>
<br>

			<table class="table text-center">
				
				

				<tr>

					<th>Cost Price</th>
					<th>Sale Price</th>
					

				</tr>

				<tr>	
					
					<td>
						
						650 Rs
					
					</td>

					<td>
						
						500 Rs
					
					</td>

					

				</tr>


			</table>

			<br>

			<table class="table text-center">
				
				

				<tr>

					<th>Category</th>
					<th>Sub Category</th>
					

				</tr>

				<tr>	
					
					<td>
						
						Electronics
					
					</td>

					<td>
						
						Home Wires
					
					</td>

					

				</tr>


			</table>

			<br>

			<table class="table text-center">
				
				

				<tr>

					<th>Unit</th>
					<th>M</th>
					

				</tr>

				


			</table><br>


			<button style="font-size: 24px; margin-bottom: 8px" class="btn btn-primary viewpagebtn">Edit</button>
			

			

		</div>
		</div> <!---col 1 ending --->


		<div class="col-md-8 col-sm-12">
		<div style="padding: 20px; margin-left: 15px" class="card ">


			<div class="row">

				<div class="col-md-4">
					
					<center>
					<img align="center" width="180px" src="https://previews.123rf.com/images/urfingus/urfingus1706/urfingus170600086/80312762-a-bunch-of-multi-colored-electric-wires-3d-illustration.jpg">
					</center>

				</div>

				<div class="col-md-4">
					
					<center>
					<img align="center" width="180px" src="https://previews.123rf.com/images/sapsiwai/sapsiwai0602/sapsiwai060200009/331405-colorful-wires.jpg">
					</center>

				</div>

				<div class="col-md-4">

					<center>
					
					<img align="center" width="180px" src="https://img2.cgtrader.com/items/420614/13724b10bb/electricity-wires-3d-model-max.jpg">

					</center>

				</div>



			</div>

			<br><br>

			<center><h4>Purchase Info</h4></center><br>
			<div class="row">
				
				
					
					<table >
						
						<table class="table text-center">
				
				

				<tr>

					<th>Purchase Place</th>
					<th>Purchase From</th>
					

				</tr>

				<tr>	
					
					<td>
						
						Lahore
					
					</td>

					<td>
						
						Hall Road
					
					</td>

					

				</tr>


			</table>

					</table>

				



			</div>


			
			<table class="table text-center">

				<center><h4 >Sellers</h4><br></center>
				

				<tr>
					<th>Seller Name</th>
					<th>Price</th>
					<th>Date</th>
					<th>Phone</th>
				</tr>

				<tr>
					<td>Ali</td>
					<td>350</td>
					<td>03/05/2020</td>
					<td>090078601</td>
				</tr>

				
				<tr>
					<td>Ramish</td>
					<td>450</td>
					<td>09/05/2020</td>
					<td>89578601</td>
				</tr>

				<tr>
					<td>Arib</td>
					<td>330</td>
					<td>04/05/2020</td>
					<td>479551121</td>
				</tr>

				<tr>
					<td>Ahmed</td>
					<td>340</td>
					<td>06/05/2020</td>
					<td>895178601</td>
				</tr>  

			</table>

			<br>


			<table class="table text-center">
				
				
				<center><h4>Product Description</h4><br></center>
				


				<tr>

					<th>Description</th>
				</tr>
				
				<tr>		
					<td>
					
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum lorem odio, pulvinar eu consequat eu, sollicitudin eget nibh. Pellentesque consectetur arcu dolor, vitae blandit est blandit elementum. Fusce vehicula in libero in euismod. In </p>
						


					</td>

				</tr>	
	


			</table>

			<br>


			<div class="row">
				
				<div class="col-md-6">

					<center><h4>Profit Graph</h4></center>

					<div  class="row my-3">
       
    </div>

     <center> <button style="width:60%; margin-left: -5px" class="btn btn-primary" data-toggle="modal" data-target="#printingkhata">Choose Date</button><br> </center>



	<!-- Modal -->
<div class="modal fade" id="printingkhata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Choose Date</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        

      	<div class="row">
      		
      		<div class="col-md-6">  


      			<label style="color: black!important" for="startdate">Starting Date</label>
				<input id="startdate" type="date" class="form-control" placeholder="Enter Date" name=""><br>

      		</div>


      		<div class="col-md-6">  


      			<label style="color: black!important" for="enddate">Ending Date</label>
				<input id="enddate" type="date" class="form-control" placeholder="Enter Date" name=""><br>

      		</div>


      	</div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary">Filter It</button>
      </div>
    </div>
  </div>
</div>



	<!--- model ending --->	


    <div class="row my-2">
        <div class="col-md-12 py-1">
            <div class="card">
                <div class="card-body">
                    <canvas height="100px" id="chLine"></canvas>
                </div>
            </div>
        </div>
        
    </div>
					
				</div>




				<div class="col-md-6">

					

					<div  class="row my-3">

						<div class="col">
         <center>   <h4>Sale Graph</h4></center>



        </div>
        
    </div>

    <center> <button style="width:60%; margin-left: -5px" class="btn btn-primary" data-toggle="modal" data-target="#printingkhata">Choose Date</button><br> </center>



	<!-- Modal -->
<div class="modal fade" id="printingkhata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Choose Date</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        

      	<div class="row">
      		
      		<div class="col-md-6">  


      			<label style="color: black!important" for="startdate">Starting Date</label>
				<input id="startdate" type="date" class="form-control" placeholder="Enter Date" name=""><br>

      		</div>


      		<div class="col-md-6">  


      			<label style="color: black!important" for="enddate">Ending Date</label>
				<input id="enddate" type="date" class="form-control" placeholder="Enter Date" name=""><br>

      		</div>


      	</div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary">Filter It</button>
      </div>
    </div>
  </div>
</div>



	<!--- model ending --->	


    <div class="row my-2">
        <div class="col-md-12 py-1">
            <div class="card">




                <div class="card-body">
                    <canvas height="100px" id="chLine2"></canvas>
                </div>
            </div>
        </div>
        
    </div>
					
				</div>



			</div>
			




<br>
			
			

			

			


		</div>

		</div><!--- col 2 ending --->








	</div><br><!--- row 1 ending --->



	

<!---
		<div style="padding: 10px" class="card ">

			<h5>Description</h5>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum lorem odio, pulvinar eu consequat eu, sollicitudin eget nibh. Pellentesque consectetur arcu dolor, vitae blandit est blandit elementum. Fusce vehicula in libero in euismod. In hac habitasse platea dictumst. Nullam feugiat convallis ex ac interdum. Cras ultricies consequat massa, vitae egestas eros commodo quis. Nullam at efficitur est, vel vulputate dui. Sed eleifend egestas tortor vitae laoreet. Curabitur ac ultricies leo. Suspendisse ut augue sit amet velit blandit hendrerit. Nullam a urna elit. Pellentesque tincidunt, ex sed egestas dapibus, purus mauris pharetra arcu, dictum suscipit mi odio at mi. Etiam tristique, augue sed pharetra feugiat, mauris ante tincidunt ex, dictum dapibus enim dolor id nisl. Praesent sit amet bibendum dolor. Ut a semper neque. Aenean vitae eros nisl.

					</p>


		</div>  --->












</div><!--- ending row margin --->








<?php include '../footer.html';?>

</body>
</html>