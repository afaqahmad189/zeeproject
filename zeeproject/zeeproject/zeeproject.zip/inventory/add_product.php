<!DOCTYPE html>
<html>




<head>
	<title>Add Product</title>
</head>
<body>

	<?php include '../header.php';?>


	<div class="container">


		<h3 class="pageheading">Add Products </h3>
		<br>

		<form>

			<div class="row"> <!--- form row 1 ---> 
			
				<div class="col">
				
					<label for="productname">Product Name</label>
					<input type="text" id="productname" class="form-control" name="" placeholder="Enter Product Name"><br>

					<label for="invetoryaffect">Invetory Affect</label>

					<select id="invetoryaffect" class="form-control">
        			<option selected>Choose...</option>
        			<option >Yes</option>
        			<option >No</option>

        			</select><br>



					

					<label for="unit">Unit</label>
					<input type="text" id="unit" class="form-control" name="" placeholder="Enter Unit"><br>

					<label for="productcost">Product Cost</label>
					<input type="text" id="productcost" class="form-control" name="" placeholder="Enter Product Cost"><br>



				</div><!--- ending first col for this form --->



				<div class="col">
				
					<label for="barcode">Barcode</label>
					<input type="text" id="barcode" class="form-control" name="" placeholder="Enter Barcode"><br>


					<div class="row">

						<div style="padding: 0" class="col col-md-12 selectcatcol">

					<label for="selectcat">Select Category</label>
					<select id="selectcat" class="form-control">
        			<option selected>Choose...</option>
        			<option value="wires">Wires</option>
        			<option value="bulbs">Bulbs</option>
        			<option value="powersupply">Power Supplies</option>
        			<option value="books">Books</option>
      				</select><br>

      					 </div>


      					 <div  class="col col-md-6 subcol">

					<label for="subcat">Select Sub Category</label>
					<select id="subcat" class="form-control">
        			<option selected>Choose...</option>
        			<option>Sub 1</option>
        			<option>Sub 2</option>
        			<option>Sub 3</option>
        			<option>Sub 4</option>
      				</select><br>

      					 </div>



      				</div>


      				<div class="row">

      					<div style="padding: 0" class="col qtycol">

      					<label for="quantity">Quantity</label>
						<input type="number" id="quantity" class="form-control" name="" placeholder="Enter Quantity"><br>

						</div>

						<div class="col-md-6 alertstockcol">

      					<label for="alertstock">Alert Stock</label>
						<input type="number" id="alertstock" class="form-control" name="" placeholder="Enter Low Stock Alert"><br>

						</div>
      					


      				</div>

					



					<label for="saleprice">Sale Price</label>
					<input type="text" id="productcost" class="form-control" name="" placeholder="Enter Discount Price"><br>



				</div>


			</div>	<!--- ending form row 1 ---> 


			<div class="row"><!--- form row 2 ---> 
				
				<div class="col">
					
					<label for="description">Description</label>
					<textarea placeholder="Enter Product Description" rows="8" class="form-control" id="description"></textarea><br>


				</div>



			</div><!--- ending form row 2 ---> 

			<div class="row"> <!--- form row 3 --->
				
				<div class="col">
					
					<label for="productplace">Product Place</label>
					<input type="text" id="productplace" class="form-control" name="" placeholder="Enter Product Place"><br>

				</div>


				<div class="col">
					
					<label for="purchasedfrom">Purchased From</label>
					<input type="text" id="purchasedfrom" class="form-control" name="" placeholder="Enter Purchased From"><br>
					
				</div> 




			</div> <!--- ending form row 3 --->

			<div class="row">
				
				<div class="col">
					
					<label for="mainpic">Product Main Picture</label>
					<input style="height: 45px" type="file" class="form-control" name="" id="mainpic"><br>


					<label for="otherpics">Product Other Pictures</label>
					<input style="height: 45px" type="file" class="form-control" name="" id="otherpics"><br>


					<label for="3dpics">Product 3D Pictures</label>
					<input style="height: 45px" type="file" class="form-control" name="" id="3dpics"><br>

				</div>




			</div>


			<br>
			<center>


				<button type="submit" class="btn formbtn"> Insert </button>

			</center>	






		</form>	


		





	</div>






<script>

$(document).ready(function(){
 $('#quantity').change(function () {
 //var job =  $('#quantity').val();
 $(".qtycol").removeClass("col");
 $(".qtycol").addClass("col-md-6");
 $('.alertstockcol').show();
})
})




</script>


<script>

$(document).ready(function(){
 $('#selectcat').change(function () {
 var job =  $('#selectcat').val();
 $(".selectcatcol").removeClass("col-md-12");
 $(".selectcatcol").addClass("col-md-6");
 $('.subcol').show();
})
})




</script>




	<?php include '../footer.html';?>

</body>
</html>