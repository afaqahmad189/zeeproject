<!DOCTYPE html>
<html>
<head>
	<title>Inventory</title>
</head>


	
<style>
	
	th {
  height: 250px!important;
  
	}

.table{

		background-color: white!important;
		padding: 20px!important;
	}

	.table > tbody > tr > td {
     vertical-align: middle;
}

.table > tbody > tr > th {
     height: 50px!important;
}

.headrow{

	margin-bottom: 50px;
}


</style>




</style>


<body>

	<?php include '../header.php';?>


	

	

<div style="padding: 15px">

	<div class="row">

	<div style="padding: 0" class="col align-middle">

	<button class="btn btn-primary">CSV</button>
	<button class="btn btn-primary">Excel</button>
	<button class="btn btn-primary">Print</button>


	</div>

	<div style="padding: 0" class="col align-middle float-right">
		

		<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Search Here..." aria-label="Recipient's username" aria-describedby="basic-addon2">
  <div class="input-group-append">
    <button class="btn btn-primary" type="button">Search</button>
  </div>
</div>


		<!---

		<input style="width: 100%; height: 50px; padding: 10px;" type="text" class="form-contol searchform" placeholder="Search Product" name="">


		--->

		


	</div>



	</div>



	

	<table style="padding: 50px; margin-top: 5px" class="table text-center">
		
		<tr class="headrow" style="margin-bottom: 5px">

			<th>ID</th>
			<th>Item Name</th>
			<th>Category</th>
			<th>Picture</th>
			<th>Remaining</th>
			<th>Product Price</th>
			<th>Action</th>
			


		</tr>



		<tr>
			

			<td>1</td>
			<td>Samsung Wire</td>
			<td>Mobiles</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>54</td>
			<td>3500 Rs</td>

			<td>
						
						<a href="/zeeproject/Inventory/view_product.php?product_id=1"><button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button></a>

						<a href="/zeeproject/Inventory/edit_product.php?product_id=1"><button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button></a>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>2</td>
			<td>Sony Wire</td>
			<td>Mobiles</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>54</td>
			<td>2500 Rs</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>3</td>
			<td>Switch</td>
			<td>Electronics</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>36</td>
			<td>1220 Rs</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>4</td>
			<td>ABCD</td>
			<td>Electronics</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>12</td>
			<td>1120 Rs</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>5</td>
			<td>Paidal</td>
			<td>Things</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>98</td>
			<td>5450 Rs</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>6</td>
			<td>WERTY</td>
			<td>FALTU</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>74</td>
			<td>30 Rs</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>7</td>
			<td>Switch</td>
			<td>Electronics</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>36</td>
			<td>1220 Rs</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>


		<tr>
			

			<td>8</td>
			<td>Bike</td>
			<td>Games</td>
			<td><button class="btn btn-primary">View Pics</button></td>
			<td>52</td>
			<td>3000 Rs</td>

			<td>
						
						<button class="btn btn-primary formbtn2"><i class="fas fa-eye"></i></button>

						<button class="btn btn-warning formbtn2"><i class="far fa-edit"></i></button>
						
						<button class="btn btn-danger formbtn2"><i class="fas fa-trash-alt"></i></button>
					

			</td>

		</tr>









	</table>




</div>


	<?php include '../footer.html';?>

</body>
</html>