<!DOCTYPE html>
<html>
<head>

<style>
	
	.card{

		padding: 15px;
	}



</style>


	<title>Top</title>
</head>
<body>

<?php include '../header.php';?>



	<div class="rowmargin">
		
		<div class="row">




		<div class="col-md-4">	


		<div class="card">
			
			<div class="card-header">
				
				<h3>Top Products </h3>

			</div>


			<table class="table">
				

			<tr>	
				
				<th>ID</th>
				<th>Product Name</th>
				<th>Product Price</th>
				<th>Lifetime Sales</th>
				<th>Lifetime Profit</th>

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>1</td>
				<td>Product1</td>
				<td>500 Rs</td>
				<td>98000</td>
				<td>150000 Rs</td>

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>2</td>
				<td>Product2</td>
				<td>980 Rs</td>
				<td>66000</td>
				<td>250000 Rs</td>

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>3</td>
				<td>Product3</td>
				<td>1980 Rs</td>
				<td>85000</td>
				<td>360000 Rs</td>

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>4</td>
				<td>Product4</td>
				<td>2780 Rs</td>
				<td>65000</td>
				<td>980000 Rs</td>

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>5</td>
				<td>Product5</td>
				<td>3680 Rs</td>
				<td>165000</td>
				<td>980000 Rs</td>

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>6</td>
				<td>Product6</td>
				<td>3680 Rs</td>
				<td>165000</td>
				<td>980000 Rs</td>

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>7</td>
				<td>Product7</td>
				<td>3680 Rs</td>
				<td>165000</td>
				<td>980000 Rs</td>

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>8</td>
				<td>Product8</td>
				<td>3680 Rs</td>
				<td>165000</td>
				<td>980000 Rs</td>

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>9</td>
				<td>Product9</td>
				<td>3680 Rs</td>
				<td>165000</td>
				<td>980000 Rs</td>

			</tr>



			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>10</td>
				<td>Product10</td>
				<td>3680 Rs</td>
				<td>165000</td>
				<td>980000 Rs</td>

			</tr>




			</table>






		</div>


	</div><!--- col 1 ending --->


	<div class="col-md-4">	


		<div class="card">
			
			<div class="card-header">
				
				<h3>Top Customers </h3>

			</div>

			<table class="table">
				

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<th >ID</th>
				<th>Name</th>
				<th>Lifetime Orders</th>
				<th>Lifetime Returns</th>
				

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>1</td>
				<td>Product1</td>
				<td>500</td>
				<td>98000</td>
				

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>2</td>
				<td>Product2</td>
				<td>980</td>
				<td>66000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>3</td>
				<td>Product3</td>
				<td>1980</td>
				<td>85000</td>
				

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>4</td>
				<td>Product4</td>
				<td>2780</td>
				<td>65000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>5</td>
				<td>Product5</td>
				<td>3680</td>
				<td>165000</td>
			

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>6</td>
				<td>Product6</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>7</td>
				<td>Product7</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>8</td>
				<td>Product8</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>9</td>
				<td>Product9</td>
				<td>3680s</td>
				<td>165000</td>
				

			</tr>



			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>10</td>
				<td>Product10</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>




			</table>


		</div>

	</div>		



		<div class="col-md-4">	


		<div class="card">
			
			<div class="card-header">
				
				<h3>Top Sellers </h3>

			</div>

			<table class="table">
				

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<th>ID</th>
				<th>Name</th>
				<th>Lifetime Sell</th>
				<th>Lifetime Returns</th>
				

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>1</td>
				<td>Product1</td>
				<td>500</td>
				<td>98000</td>
				

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>2</td>
				<td>Product2</td>
				<td>980 Rs</td>
				<td>66000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>3</td>
				<td>Product3</td>
				<td>1980</td>
				<td>85000</td>
				

			</tr>

			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>4</td>
				<td>Product4</td>
				<td>2780</td>
				<td>65000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>5</td>
				<td>Product5</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>6</td>
				<td>Product6</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>7</td>
				<td>Product7</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>8</td>
				<td>Product8</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>


			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>9</td>
				<td>Product9</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>



			<tr data-toggle="modal" data-target="#exampleModal">	
				
				<td>10</td>
				<td>Product10</td>
				<td>3680</td>
				<td>165000</td>
				

			</tr>




			</table>
	






		</div>


	</div><!--- col 3 ending --->

</div>


	</div><!--- row margin ending --->



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

	<div class="row">
      		
      		<div class="col-md-6">  


      			<label style="color: black!important" for="startdate">Starting Date</label>
				<input id="startdate" type="date" class="form-control" placeholder="Enter Date" name=""><br>

      		</div>


      		<div class="col-md-6">  


      			<label style="color: black!important" for="enddate">Ending Date</label>
				<input id="enddate" type="date" class="form-control" placeholder="Enter Date" name=""><br>

      		</div>


      	</div>




      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <a href="/zeeproject/report/top_result.php">  <button type="button" class="btn btn-primary">Check Result</button>
      </div>
    </div>
  </div>
</div>







<br>
<?php include '../footer.html';?>

</body>
</html>